from django.contrib import admin
from stock.models import Companies

# Register your models here.
admin.site.register(Companies)
